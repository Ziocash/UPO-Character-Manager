package internal.classes;

public class Points
{
	protected class P1 
	{
		private final int value = 0;
		private final String description = "";

		public int getValue()
		{
			return value;
		}

		public String getDescription()
		{
			return description;
		}
	}

}
