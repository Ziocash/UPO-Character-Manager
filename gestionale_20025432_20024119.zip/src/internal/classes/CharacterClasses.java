package internal.classes;

/**
 * @author Simone Gattini
 *
 */
public enum CharacterClasses
{
	/**
	 * 
	 */
	WARRIOR,
	/**
	 * 
	 */
	ROGUE,
	/**
	 * 
	 */
	MAGE	
}
