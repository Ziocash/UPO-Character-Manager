# Java Character Management System

- Java based project
- Currently under active development

### Issues or bugs
[Click here](https://github.com/Ziocash/development-Java/issues/new) to submit an issue


### File necessari

- characters.txt
- abilities.txt